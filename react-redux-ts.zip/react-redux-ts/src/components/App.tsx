import React from 'react';
import { connect } from 'react-redux';
import { Todos, fetchTodos } from '../actions'
import { StoreState } from '../reducers'

interface Appprops {
    todos: Todos[],
    fetchTodos(): any
}
export class App extends React.Component<Appprops> {
    render() {
        return <div>Hi there :) !</div>;
    }
}

const mapStateToProps = ( { todos }: StoreState): { todos: Todos[] } => {
    return { todos };
}